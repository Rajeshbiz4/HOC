import React from 'react'

const Workspace = props => (
  <div className="users-page">
    Workspace    
  </div>
)

export default Workspace