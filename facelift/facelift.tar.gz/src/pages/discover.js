import React from 'react'

const Discover = props => (
  <div className="users-page">
    Discover    
  </div>
)

export default Discover