import React from 'react'

const PageNotFound = props => <h2>Page not found.</h2>

export default PageNotFound