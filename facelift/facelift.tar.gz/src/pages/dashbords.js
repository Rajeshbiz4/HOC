import React from 'react'
import Container from '../components/info-card/card-container';

const DashBoard = props => (
  <div className="users-page">
    DashBoard    
    <Container />
  </div>
)

export default DashBoard