

export const getNewsAction = 'demo'