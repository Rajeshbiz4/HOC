import React from 'react';
import TabComponent from '../tab/tab'
import getNewsAction from '../utility'

const sortByClarivate = [
  { name: 'General', value: 'general' },
  { name: 'Development', value: 'development' },
  { name: 'Financial', value: 'financial' },
  { name: 'Analysis', value: 'analysis' },
  { name: 'Patent Families', value: 'patentfamilies' },
  { name: 'Sources', value: 'sources' },
  { name: 'Change History', value: 'changehistory' }]

const sortByTabsIntervention = [
  { name: "Drug Highlights", value: "drughighlights" },
  { name: "Pharmacological Properties", value: "pharmacologicalproperties" },
  { name: "Trial Landscape", value: "triallandscape" },
  { name: "Recent Events", value: "recentevents" }];

const sortByTabsGene = [
  { name: "Gene Summary", value: "genesummary" },
  { name: "Location", value: "location" },
  { name: "Gene Ontology", value: "geneontology" },
  { name: "Associated Pathways", value: "associatedpathways" },
  { name: "Phenotypes", value: "phenotypes" },
  { name: "Associated Drugs", value: "associateddrugs" }];

const tabList = [
  { menuItem: 'Tab 1', render: () => <TabComponent data={sortByClarivate} />, render: <TabComponent data={sortByClarivate} /> },
  { menuItem: 'Tab 1', render: () => <TabComponent data={sortByClarivate} />, render: TabComponent }]
class View extends React.Component {
  constructor(props) {
    super(props)
  }


  render() {
    return (
      <div className='body'>
        <div className='leftalign'>
          <a href=''>Back | {this.props.data.name} | {this.props.data.key} </a>
          <div>

          </div>
        </div>
        <div>Content
           <TabComponent data={tabList} />
        </div>
      </div>
    );
  }
}
export default View;